// always use this name
var js_translation = new Object();

js_translation['tooltip_stamp'] = 'Stamp tool (click to show available stamps)';
js_translation['tooltip_stampcategory'] = 'Click to show available stamps';
js_translation['tooltip_select'] = 'Pointer for selection';
js_translation['tooltip_linetool'] = 'Line tool (click to show available line types)';
js_translation['tooltip_shapes'] = 'Shape tool (click to show available shapes)';
js_translation['tooltip_text'] = 'Text tool (click to show available font sizes)';
js_translation['tooltip_stroke'] = 'Stroke colour (click to show available colours)';
js_translation['tooltip_fill'] = 'Fill colour (click to show available colours)';
js_translation['tooltip_trash'] = 'Delete selected objects';
js_translation['tooltip_line'] = 'Line';
js_translation['tooltip_arrow'] = 'Arrow';
js_translation['tooltip_doubleArrow'] = 'Double arrow';
js_translation['tooltip_rectangle'] = 'Rectangle';
js_translation['tooltip_ellipse'] = 'Ellipse';
js_translation['tooltip_square'] = 'Square';
js_translation['tooltip_circle'] = 'Circle';

