$(window).load(function () {
    $($('#T540Q03RADIO_0').next()).html('<img width="350px" src="' + getUserVar('T540_DT_1_image') + '"/>');
    $($('#T540Q03RADIO_1').next()).html('<img width="350px" src="' + getUserVar('T540_DT_2_image') + '"/>');
});
